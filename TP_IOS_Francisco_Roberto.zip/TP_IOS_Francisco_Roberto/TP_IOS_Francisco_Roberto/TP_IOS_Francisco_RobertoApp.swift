//
//  TP_IOS_Francisco_RobertoApp.swift
//  TP_IOS_Francisco_Roberto
//
//  Created by MultiLab PRT 07 on 16/09/2025.
//

import SwiftUI

@main
struct TP_IOS_Francisco_RobertoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
